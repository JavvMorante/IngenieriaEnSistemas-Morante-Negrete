﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Servicios_60MN
{
    public class LoginResult_60MN
    {

        public enum LoginResult 
        { 
        InvalidUsername,
            InvalidPassword,
            ValidUser
        }
    }
}
